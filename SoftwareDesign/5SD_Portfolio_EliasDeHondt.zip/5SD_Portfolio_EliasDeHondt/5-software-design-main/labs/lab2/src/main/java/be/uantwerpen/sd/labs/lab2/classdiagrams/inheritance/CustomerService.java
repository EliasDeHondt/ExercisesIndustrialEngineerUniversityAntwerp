// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab2.classdiagrams.inheritance;

public class CustomerService extends Employee {
    protected double bonusPerCostumer; // bonusPerCustomer
    protected double numberOfCostumers; // // numberOfCustomers

    public CustomerService(double hourlySalary, double hoursWorked, double bonusPerCostumer, double numberOfCostumers) {
        super(hourlySalary, hoursWorked);
        this.bonusPerCostumer = bonusPerCostumer;
        this.numberOfCostumers = numberOfCostumers;
    }

    @Override
    public double calculateDailySalary() {
        return  hourlySalary * hoursWorked + (bonusPerCostumer * numberOfCostumers);
    }
}