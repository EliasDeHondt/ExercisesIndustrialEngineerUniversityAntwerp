// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab2.classdiagrams.interfaces;

public interface VolumeDevice {
    void volumeUp();
    void volumeDown();
}