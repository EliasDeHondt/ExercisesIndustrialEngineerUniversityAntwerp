// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab2.classdiagrams.relations;

public class FeatureFilm extends Work {
    public FeatureFilm(String title, int runtimeMinutes) {
        super(title, runtimeMinutes);
    }
}