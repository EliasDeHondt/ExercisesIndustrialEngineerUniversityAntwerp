// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab2.classdiagrams.relations;

public class Staff extends Person {
    public Staff(String name) {
        super(name);
    }
}