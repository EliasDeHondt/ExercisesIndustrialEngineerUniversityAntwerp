// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab4b.level;

public abstract class Level {
    public abstract int extraPullBias();
}