// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab4b.model.domain;

public abstract class Box extends Entity {
    @Override
    public boolean isBox() {
        return true;
    }
}