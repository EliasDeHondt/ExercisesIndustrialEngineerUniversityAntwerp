// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab4b.logic.glacier;
import be.uantwerpen.sd.labs.lab4b.logic.CoveragePolicy;
import be.uantwerpen.sd.labs.lab4b.model.domain.Box;
import be.uantwerpen.sd.labs.lab4b.model.domain.Entity;
import be.uantwerpen.sd.labs.lab4b.model.domain.Player;

public final class GlacierCoveragePolicy extends CoveragePolicy {
    @Override
    public boolean countsForCoverage(Entity e) {
        return e != null && (e instanceof Box || e instanceof Player);
    }
}