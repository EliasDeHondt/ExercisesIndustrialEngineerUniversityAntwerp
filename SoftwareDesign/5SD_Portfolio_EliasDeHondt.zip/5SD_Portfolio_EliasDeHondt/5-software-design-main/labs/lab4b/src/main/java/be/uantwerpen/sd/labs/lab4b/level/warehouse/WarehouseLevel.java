// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab4b.level.warehouse;
import be.uantwerpen.sd.labs.lab4b.level.Level;

public final class WarehouseLevel extends Level {
    @Override
    public int extraPullBias() {
        return 0;
    }
}