// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab4b.logic.warehouse;
import be.uantwerpen.sd.labs.lab4b.logic.CoveragePolicy;
import be.uantwerpen.sd.labs.lab4b.model.domain.Box;
import be.uantwerpen.sd.labs.lab4b.model.domain.Entity;

public final class WarehouseCoveragePolicy extends CoveragePolicy {
    @Override
    public boolean countsForCoverage(Entity e) {
        return e != null && e instanceof Box;
    }
}