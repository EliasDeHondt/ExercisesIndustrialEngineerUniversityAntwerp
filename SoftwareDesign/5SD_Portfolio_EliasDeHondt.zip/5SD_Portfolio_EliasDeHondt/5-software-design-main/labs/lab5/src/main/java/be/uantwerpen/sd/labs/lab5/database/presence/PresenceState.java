// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab5.database.presence;

public interface PresenceState {
    boolean canCheckIn();

    boolean canCheckOut();

    PresenceState onCheckIn();

    PresenceState onCheckOut();
}