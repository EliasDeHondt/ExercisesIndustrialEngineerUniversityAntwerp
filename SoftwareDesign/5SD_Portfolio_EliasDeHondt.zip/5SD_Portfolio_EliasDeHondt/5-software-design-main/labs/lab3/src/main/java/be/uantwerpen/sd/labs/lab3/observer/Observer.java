// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab3.observer;

public interface Observer {
    void update(String event, Object payload);
}