// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab3.singleton;

public class TicketService {
    public Ticket create(String title) {
        IdGenerator generator = IdGenerator.getInstance();
        long newId = generator.nextId();
        return new Ticket(newId, title);
    }
}