// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab3.inventory;

public class Controller {
    private final InventoryDB db;

    public Controller(InventoryDB db) {
        this.db = db;
    }

    public void adjust(String sku, int newQty) {
        db.setStock(sku, newQty);
    }
}