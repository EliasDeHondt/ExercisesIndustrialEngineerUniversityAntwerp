// @author EliasDH Team
// @see https://eliasdh.com
// @since 01/01/2025

package be.uantwerpen.sd.labs.lab4a.planners;
import be.uantwerpen.sd.labs.lab4a.Plant;
import be.uantwerpen.sd.labs.lab4a.ReforestationPlanner;
import be.uantwerpen.sd.labs.lab4a.plants.Pine;

public class PinePlanner extends ReforestationPlanner {
    @Override
    protected Plant createPlant() {
        return new Pine();
    }
}